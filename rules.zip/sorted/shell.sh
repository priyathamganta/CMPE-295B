#!/bin/bash
for file in ./*/*.rules
do
  less $file | grep '^alert' | wc -l
  echo " $file"
done

